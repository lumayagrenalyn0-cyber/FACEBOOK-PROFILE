import React from 'react';
import Header from './components/Header';
import ProfileCover from './components/ProfileCover';
import ProfileNavigation from './components/ProfileNavigation';
import Intro from './components/Intro';
import PostsSection from './components/PostsSection';
import FriendsGrid from './components/FriendsGrid';
import './App.css';

function App() {
  const userData = {
    name: 'Aldwin Lance Astillero',
    profilePicture: './pfp-me.jpeg',
    coverPhoto: 'cover.jpeg',
    bio: 'Gay Nigga 89.',
    details: [
      'Lives in Osaka Japan',
      'From Tondo, Manila',
      'Followed by 6 people'
    ],
    friends: [
      { id: 1, name: 'Asumi Sagun', avatar: 'pfp-sagun.jpg' },
      { id: 2, name: 'Arween Garcing', avatar: 'pfp-garcing.jpg' },
      { id: 3, name: 'Charles Bayobay', avatar: 'pfp-bayobay.jpg' },
      { id: 4, name: 'Troy Troy', avatar: 'pfp-troy.jpg' },
      { id: 5, name: 'Kim Marcial', avatar: 'pfp-marcial.jpg' },
      { id: 6, name: 'Puno ng Saging', avatar: 'pfp-saging.jpg' },
    ],
    posts: [
      {
        id: 1,
        author: 'Aldwin Lance Astillero',
        authorAvatar: './pfp-me.jpeg',
        timestamp: '2 hours ago',
        content: "Peak Ba Tong Dhon sa Saging?",
        image: ''
      },
      {
        id: 2,
        author: 'Aldwin Lance Astillero',
        authorAvatar: './pfp-me.jpeg',
        timestamp: 'Yesterday',
        content: "Black Dudes Are Shaking!!.",
        image: ''
      }
    ]
  };

  return (
    <div className="App">
      <Header userName={userData.name} profilePicture={userData.profilePicture} />
      <div className="profile-container">
        <ProfileCover coverPhoto={userData.coverPhoto} profilePicture={userData.profilePicture} userName={userData.name} />
        <ProfileNavigation />
        <div className="profile-content">
          <div className="profile-sidebar">
            <Intro bio={userData.bio} details={userData.details} />
            <FriendsGrid friends={userData.friends} />
          </div>
          <div className="profile-main-content">
            <PostsSection posts={userData.posts} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;